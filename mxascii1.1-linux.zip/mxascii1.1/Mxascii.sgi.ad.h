"MXascii*sgiMode: true",
"MXascii*useSchemes: Colors",
"MXascii*scheme: Base",
"MXascii*menuBar*fontList: -*-helvetica-bold-r-*-*-*-100-*-*-*-*-iso8859-*",
"MXascii*keyboardFocusPolicy: pointer",
"MXascii*background: gray75",
"MXascii*msgrcw*background: black",
"MXascii*msgrcw*foreground: white",
"MXascii*msgtextw*fontList: *helvetica-medium-r-normal--12*",
"MXascii**msgtextw.marginHeight: 0",
"MXascii*label.foreground: red",
"MXascii*label.background: #cccccc",
"MXascii*leftlabel2.background: white",
"MXascii*leftlabel2.foreground: blue",
"MXascii*aboutd.messageAlignment: alignment_center",
"MXascii*aboutd*fontList: lucidasans-12,lucidasans-bold-12=BOLD,lucidasans-bold-18=BIG,lucidasans-10=SMALL,lucidasans-italic-12=ITALIC",
"MXascii*aboutd.messageString:\
<BIG>mxascii Release 1.1<>\\n\
<SMALL>[Jun 22, 1996,Saturday]<>\\n\
\\n\
ASCII Character set\\n\
By\\n\
<ITALIC>Muhammad A. Muquit<>\\n\
\\n\
http://www.fccc.edu/users/muquit/\\n\
<BOLD><SMALL>MA_Muquit@fccc.edu",
