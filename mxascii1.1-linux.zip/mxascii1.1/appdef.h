#ifndef _APPDEF_H
#define _APPDEF_H

#if defined (sgi)
#include "Mxascii.sgi.ad.h"
#else
#include "Mxascii.ad.h"
#endif

#endif /* _APPDEF_H */
