#ifndef CONVERTER_H
#define CONVERTER_H 1

XmString
    XitStringToXmString (String);

void
    XitAddXmStringConverter (XtAppContext);

#endif /* CONVERTER_H */
